__all__ = ['autointerface']
import autointerface

__version__ = "0.2"


