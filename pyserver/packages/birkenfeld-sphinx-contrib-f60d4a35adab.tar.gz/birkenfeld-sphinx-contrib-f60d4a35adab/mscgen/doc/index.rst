.. This is the main documentation to use as a simple website.

.. include:: ../README


ChangeLog
=========

.. include:: ../CHANGES


License
=======

.. include:: ../LICENSE
    :literal:

