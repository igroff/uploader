========================================
Welcome to sdedit extension's for Sphinx
========================================

.. include:: ../README

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

ChangeLog
=========

.. include:: ../CHANGES

License
=======

.. include:: ../LICENSE
    :literal:
