Sadisplay Example
=================

Simple plantuml class diagram:

.. sadisplay::
    :module: model
