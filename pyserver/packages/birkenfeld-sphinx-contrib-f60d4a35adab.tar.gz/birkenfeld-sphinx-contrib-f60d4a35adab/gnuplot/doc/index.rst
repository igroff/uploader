
.. include:: ../README



License
=======

.. include:: ../LICENSE
    :literal:

