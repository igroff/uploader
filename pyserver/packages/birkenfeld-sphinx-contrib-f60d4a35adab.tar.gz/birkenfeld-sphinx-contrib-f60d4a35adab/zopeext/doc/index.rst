.. This is the main documentation to use as a simple website.

.. include:: ../README

=========
ChangeLog
=========

.. include:: ../CHANGES

=======
Details
=======

.. automodule:: sphinxcontrib.zopeext.autointerface
   :members:

=======
License
=======

.. include:: ../../LICENSE
    :literal:

