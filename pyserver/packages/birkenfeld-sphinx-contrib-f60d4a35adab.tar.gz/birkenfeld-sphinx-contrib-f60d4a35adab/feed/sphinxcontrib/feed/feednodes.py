from docutils import nodes

class latest(nodes.General, nodes.Element):
    """This will be automagically transformed into an overview of latest
    articles"""

