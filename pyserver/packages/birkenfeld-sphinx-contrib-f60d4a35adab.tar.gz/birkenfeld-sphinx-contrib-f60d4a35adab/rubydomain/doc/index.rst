.. sphinxcontrib-rubydomain documentation master file, created by
   sphinx-quickstart on Sun Apr 25 13:26:33 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: ../README

Contents:

.. toctree::
   :maxdepth: 2

   reference
   sample_doc

* :ref:`genindex`
* :ref:`search`

ChangeLog
=========

.. include:: ../CHANGES


License
=======

.. include:: ../LICENSE
    :literal:

