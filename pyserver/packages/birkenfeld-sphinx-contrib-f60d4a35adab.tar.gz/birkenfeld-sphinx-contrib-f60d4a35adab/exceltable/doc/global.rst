
.. _Docutils: http://docutils.sourceforge.net/
.. _Docutils directives: http://docutils.sourceforge.net/docs/ref/rst/directives.html
.. _Paver: http://www.blueskyonmars.com/projects/paver/index.html
.. _RST: http://docutils.sourceforge.net/
.. _Sphinx: http://sphinx.pocoo.org/
.. _Rusty: http://pypi.python.org/pypi/rusty
.. _include: http://docutils.sourceforge.net/docs/ref/rst/directives.html#including-an-external-document-fragment
.. _ReStructuredText: http://docutils.sourceforge.net/rst.html
.. _BeautifulSoup: http://www.crummy.com/software/BeautifulSoup/
.. _xlrd: http://www.python-excel.org/
.. _tox: http://tox.readthedocs.org/en/latest/
.. _nose: http://code.google.com/p/python-nose/
.. _coverage: http://nedbatchelder.com/code/coverage/
.. _sqlparse: http://code.google.com/p/python-sqlparse/
