Function reference
==================

.. automodule:: sphinxcontrib.doxylink.doxylink

.. automodule:: sphinxcontrib.doxylink.parsing
