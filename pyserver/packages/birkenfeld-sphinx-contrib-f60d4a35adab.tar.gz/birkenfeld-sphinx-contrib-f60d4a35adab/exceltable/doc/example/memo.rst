
**Meeting minutes**

:author: Alan Author
:date: 2008-04-21

.. IMPORTANT:: Action points

    .. regxlist:: (AP|-->)+\s+(to)*\s*(?P<name>(\w|\s)+):\s*(?P<desc>(\w|\n|\s)*) 
       :template: ${name}: ${desc}
       :siblings:
       :levelsup: 2
  
- Software building process is still hard, AP Sarah: improve building process
- AP to Tom: document the building process
- Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean risus mauris, 
  ultrices id, pretium sed, lobortis in, nisl. Nunc tincidunt neque vel libero 
  hendrerit malesuada.
- Pellentesque dolor augue, dapibus dictum, elementum quis, tincidunt consectetur, 
  nunc. Sed vulputate dolor ut sem. In varius rutrum odio.   
- Release needs to be ready for monday --> Sarah: create official release
- Nunc sit amet neque sed lorem condimentum interdum. In hac habitasse platea dictumst. 
  Vivamus vel libero eget lectus ultrices vestibulum.
- Blah blah...
