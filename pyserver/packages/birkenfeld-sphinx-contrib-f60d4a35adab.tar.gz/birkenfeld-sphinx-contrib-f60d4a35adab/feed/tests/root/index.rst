Welcome to Sphinx Feed <Test>'s documentation!
===================================================

Contents:

.. toctree::
    :maxdepth: 2
    :glob:
    :hidden:
    
    *

.. latest::
    :glob:

    *


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

