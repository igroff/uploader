PlantUML Example
================

Class diagram:

.. uml::

   Foo <|-- Bar

Sequence diagram:

.. uml::

   Alice -> Bob: Hello!
   Alice <- Bob: Hi!

Sequence diagram in Japanese:

.. uml::

   花子 -> 太郎: こんにちは!
   花子 <- 太郎: うっす!
