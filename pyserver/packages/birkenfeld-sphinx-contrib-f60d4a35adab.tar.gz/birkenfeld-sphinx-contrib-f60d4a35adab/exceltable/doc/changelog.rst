.. _changelog:

.. _changes:

Changelog
=========
This sections lists the notable changes done per release.

.. contents::
   :local:

.. include:: ../CHANGES
