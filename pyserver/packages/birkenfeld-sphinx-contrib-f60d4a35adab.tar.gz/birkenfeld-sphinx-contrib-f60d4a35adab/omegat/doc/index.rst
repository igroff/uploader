.. include:: ../README

Contents:

.. toctree::
   :maxdepth: 2

   reference
   sample_doc

* :ref:`genindex`
* :ref:`search`

ChangeLog
=========

.. include:: ../CHANGES


License
=======

.. include:: ../LICENSE
    :literal:

