.. sphinxcontrib-osaka documentation master file, created by
   sphinx-quickstart on Sat Apr 10 11:39:05 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: ../README

Sample Document
===============

Compare source with result.

.. toctree::
   :maxdepth: 1

   sample
   python_tutorial


ChangeLog
=========

.. include:: ../CHANGES


License
=======

.. include:: ../LICENSE
    :literal:


