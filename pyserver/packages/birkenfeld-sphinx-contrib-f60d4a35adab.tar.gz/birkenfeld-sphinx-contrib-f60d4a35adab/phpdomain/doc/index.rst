.. include:: ../README

Contents:
---------

.. toctree::
   :maxdepth: 2

   reference

* :ref:`genindex`
* :ref:`search`

ChangeLog
=========

.. include:: ../CHANGES

