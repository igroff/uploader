
"""
TODO: add a docstring.

"""

from pystache import TemplateSpec

class Simple(TemplateSpec):

    def thing(self):
        return "pizza"

    def blank(self):
        return ''
