:Date: 2001-08-11 13:00:00
:Author: Santa
:Weird Field: buff
:Tag Thing: fish calliope melon

The latest blog post
====================

Has the latest content.

It also has :doc:`a relative link <A_older>`.

Not to mention `an absolute link <http://google.com/>`_
