
"""
TODO: add a docstring.

"""

class Unescaped(object):

    def title(self):
        return "Bear > Shark"
